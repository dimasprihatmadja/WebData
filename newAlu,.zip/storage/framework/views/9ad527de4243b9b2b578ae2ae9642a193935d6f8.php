<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Edit Biodata Alumni</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../alumni/assets/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../alumni/assets/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="../alumni/assets/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="../alumni/assets/images/binterbusih.png" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <link href="../alumni/assets2/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
  <link href="../alumni/assets2/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
  <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <link href="../alumni/assets2/vendor/select2/select2.min.css" rel="stylesheet" media="all">
  <link href="../alumni/assets2/vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">
  <link href="../alumni/assets2/css/main.css" rel="stylesheet" media="all">

  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo" href="/superadmin">
          <h3>SI ALUMNI</h3>
        </a>
        <a class="navbar-brand brand-logo-mini" href="/superadmin">
          <h3>SIA</h3>
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-stretch">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
          <span class="mdi mdi-menu"></span>
        </button>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item nav-profile dropdown">
            <a class="nav-link dropdown-toggle" id="profileDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <div class="nav-profile-text">
                <p class="mb-1 text-black"><?php echo session()->get("nama"); ?></p>
              </div>
            </a>
            <div class="dropdown-menu navbar-dropdown" aria-labelledby="profileDropdown">
              <a class="dropdown-item" href="/">
                <i class="mdi mdi-logout mr-2 text-primary"></i> Signout </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="mdi mdi-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
              <div class="nav-profile-text d-flex flex-column">
                <span class="font-weight-bold mb-2"><?php echo session()->get("nama"); ?></span>
                <span class="text-secondary text-small"><?php echo session()->get("role"); ?></span>
              </div>

            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/superadmin">
              <span class="menu-title">Home</span>
              <i class="mdi mdi-home menu-icon"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/data_Alumni">
              <span class="menu-title">Data Alumni</span>
              <i class="mdi mdi-table-large menu-icon"></i>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="true" aria-controls="ui-basic">
              <span class="menu-title">Laporan</span>
              <i class="menu-arrow"></i>
              <i class="mdi mdi-clipboard-text menu-icon"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="/grafik" style="color: #434a54;">Grafik Laporan</a></li>
                <li class="nav-item"> <a class="nav-link" href="/cetaklaporan" style="color: #434a54;">Cetak Laporan</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/kelola_akun">
              <span class="menu-title">Kelola Akun</span>
              <i class="mdi mdi-account-multiple menu-icon"></i>
            </a>
          </li>
          <li class="nav-item sidebar-actions">
            <span class="nav-link">
              <div class="border-bottom">
                <h6 class="font-weight-normal mb-3">Input Data</h6>
              </div>
              <a class="btn btn-block btn-lg btn-gradient-info mt-4" href="/formAlumni">+Input</a>
            </span>
          </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <h1 class="title">Edit Biodata <?php echo e($data->nama); ?></h1> <br> <br>
                <h1 class="title_2">Data Pribadi Peserta</h1>
                <form method="post" action="/updatealumni/superadmin" enctype="multipart/form-data">
                  <?php echo e(csrf_field()); ?>

                  <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                  <div class="row row-space">
                    <div class="">
                      <div class="input-group">
                        <label class="label">Nama Asli/Lengkap: </label>
                        <input class="input--style-4" type="text" name="nama_asli" value="<?php echo e($data->nama); ?>" required>
                      </div>
                    </div>
                  </div>

                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Tempat Lahir: </label>
                        <input class="input--style-4" type="text" name="tempat" value="<?php echo e($data->tempat); ?>" required>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Tanggal Lahir: </label>
                        <input class="input--style-4" type="date" name="tanggal_lahir" value="<?php echo e($data->tanggal_lahir); ?>" required>
                      </div>
                    </div>
                  </div>

                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Alamat Lengkap</label>
                        <input class="input--style-4" type="text" name="alamat_lgkp" value="<?php echo e($data->alamat); ?>" required>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Jenis Kelamin</label>
                        <div class="input-group">
                          <select class="form-select" id="inputGroupSelect02" name="gender" value="<?php echo e($data->jenis_kelamin); ?>">

                            <option value="Laki-Laki" <?php if($data->jenis_kelamin == 'Laki-Laki'): ?> selected <?php endif; ?>>Laki-Laki</option>
                            <option value="Perempuan" <?php if($data->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                            <!-- <option value="Laki-Laki">Laki-Laki</option>
                            <option value="Perempuan">Perempuan</option> -->
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label for="formFile" class="label">Upload Foto</label>
                        <input type="file" id="foto" name="foto">
                        <small id="passwordHelpBlock" class="form-text text-muted">
                          Maksimal file 2 MB
                        </small>
                      </div>
                    </div>
                    <?php $aslkab = DB::table('tb_kota')->get(); ?>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Asal Kabupaten: </label>
                        <div class="input-group">
                          <select class="custom-select form-control" name="aslkab" id="aslkab" required>
                            <option hidden><?php echo e($data->asal_kabupaten); ?></option>
                            <?php $__currentLoopData = $aslkab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($a->kota); ?>"><?php echo e($a->kota); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Agama: </label>
                        <div class="input-group">
                          <select class="form-select" id="inputGroupSelect03" name="agama" required>
                            <option selected value="Islam" <?php if($data->agama == 'Islam'): ?> selected <?php endif; ?>>Islam</option>
                            <option value="kristen" <?php if($data->agama == 'kristen'): ?> selected <?php endif; ?>>kristen</option>
                            <option value="hindu" <?php if($data->agama == 'hindu'): ?> selected <?php endif; ?>>hindu</option>
                            <option value="budha" <?php if($data->agama == 'budha'): ?> selected <?php endif; ?>>budha</option>
                            <option value="konghucu" <?php if($data->agama == 'konghucu'): ?> selected <?php endif; ?>>konghucu</option>
                            <option value="lainnya" <?php if($data->agama == 'lainnya'): ?> selected <?php endif; ?>>lainnya</option>
                          </select>
                          <!-- <input class="input--style-4" type="text" name="agama" required> -->
                        </div>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Suku: </label>
                        <div class="input-group">
                          <select class="form-select select2" id="inputGroupSelect03" name="suku" required>
                            <option selected value="Suku Amungme" <?php if($data->suku == 'Suku Amungme'): ?> selected <?php endif; ?>>Suku Amungme</option>
                            <option value="Suku Arfak" <?php if($data->suku == 'Suku Arfak'): ?> selected <?php endif; ?>>Suku Arfak</option>
                            <option value="Suku Arguni" <?php if($data->suku == 'Suku Arguni'): ?> selected <?php endif; ?>>Suku Arguni</option>
                            <option value="Suku Asmat" <?php if($data->suku == 'Suku Asmat'): ?> selected <?php endif; ?>>Suku Asmat</option>
                            <option value="Suku Awyu" <?php if($data->suku == 'Suku Awyu'): ?> selected <?php endif; ?>>Suku Awyu</option>
                            <option value="Suku Ayfat" <?php if($data->suku == 'Suku Ayfat'): ?> selected <?php endif; ?>>Suku Ayfat</option>
                            <option value="Suku Baham" <?php if($data->suku == 'Suku Baham'): ?> selected <?php endif; ?>>Suku Baham</option>
                            <option value="Suku Damal" <?php if($data->suku == 'Suku Damal'): ?> selected <?php endif; ?>>Suku Damal</option>
                            <option value="Suku Dani" <?php if($data->suku == 'Suku Dani'): ?> selected <?php endif; ?>>Suku Dani</option>
                            <option value="Suku Fayu" <?php if($data->suku == 'Suku Fayu'): ?> selected <?php endif; ?>>Suku Fayu</option>
                            <option value="Suku Huli" <?php if($data->suku == 'Suku Huli'): ?> selected <?php endif; ?>>Suku Huli</option>
                            <option value="Suku Kamoro" <?php if($data->suku == 'Suku Kamoro'): ?> selected <?php endif; ?>>Suku Kamoro</option>
                            <option value="Suku Lani" <?php if($data->suku == 'Suku Lani'): ?> selected <?php endif; ?>>Suku Lani</option>
                            <option value="Suku Marind" <?php if($data->suku == 'Suku Marind'): ?> selected <?php endif; ?>>Suku Marind</option>
                            <option value="Suku Melayu" <?php if($data->suku == 'Suku Melayu'): ?> selected <?php endif; ?>>Suku Melayu</option>
                            <option value="Suku Moni" <?php if($data->suku == 'Suku Moni'): ?> selected <?php endif; ?>>Suku Moni</option>
                            <option value="Suku Motu" <?php if($data->suku == 'Suku Motu'): ?> selected <?php endif; ?>>Suku Motu</option>
                            <option value="Suku Ansus" <?php if($data->suku == 'Suku Ansus'): ?> selected <?php endif; ?>>Suku Ansus</option>
                            <option value="Suku Awyi" <?php if($data->suku == 'Suku Awyi'): ?> selected <?php endif; ?>>Suku Awyi</option>
                            <option value="Suku Baburua" <?php if($data->suku == 'Suku Baburua'): ?> selected <?php endif; ?>>Suku Baburua</option>
                            <option value="Suku Banlol" <?php if($data->suku == 'Suku Banlol'): ?> selected <?php endif; ?>>Suku Banlol</option>
                            <option value="Suku Berik" <?php if($data->suku == 'Suku Berik'): ?> selected <?php endif; ?>>Suku Berik</option>
                            <option value="Suku Biak" <?php if($data->suku == 'Suku Biak'): ?> selected <?php endif; ?>>Suku Biak</option>
                            <option value="Suku Biksi" <?php if($data->suku == 'Suku Biksi'): ?> selected <?php endif; ?>>Suku Biksi</option>
                            <option value="Suku Buruwai" <?php if($data->suku == 'Suku Buruwai'): ?> selected <?php endif; ?>>Suku Buruwai</option>
                            <option value="Suku Busami" <?php if($data->suku == 'Suku Busami'): ?> selected <?php endif; ?>>Suku Busami</option>
                            <option value="Suku Citak Mitak" <?php if($data->suku == 'Suku Citak Mitak'): ?> selected <?php endif; ?>>Suku Citak Mitak</option>
                            <option value="Suku Dem" <?php if($data->suku == 'Suku Dem'): ?> selected <?php endif; ?>>Suku Dem</option>
                            <option value="Suku Demta" <?php if($data->suku == 'Suku Demta'): ?> selected <?php endif; ?>>Suku Demta</option>
                            <option value="Suku Dera" <?php if($data->suku == 'Suku Dera'): ?> selected <?php endif; ?>>Suku Dera</option>
                            <option value="Suku Enggros" <?php if($data->suku == 'Suku Enggros'): ?> selected <?php endif; ?>>Suku Enggros</option>
                            <option value="Suku Hanasbey" <?php if($data->suku == 'Suku Hanasbey'): ?> selected <?php endif; ?>>Suku Hanasbey</option>
                            <option value="Suku Mander" <?php if($data->suku == 'Suku Mander'): ?> selected <?php endif; ?>>Suku Mander</option>
                            <option value="Suku Hanasbey" <?php if($data->suku == 'Suku Hanasbey'): ?> selected <?php endif; ?>>Suku Hanasbey</option>
                            <option value="Suku Marengge" <?php if($data->suku == 'Suku Marengge'): ?> selected <?php endif; ?>>Suku Marengge</option>
                            <option value="Suku Mbaham-Matta" <?php if($data->suku == 'Suku Mbaham-Matta'): ?> selected <?php endif; ?>>Suku Mbaham-Matta</option>
                            <option value="Melayu-Indonesia" <?php if($data->suku == 'Melayu-Indonesia'): ?> selected <?php endif; ?>>Melayu-Indonesia</option>
                            <option value="Suku Meybrat" <?php if($data->suku == 'Suku Meybrat'): ?> selected <?php endif; ?>>Suku Meybrat</option>
                            <option value="Suku Ngalum" <?php if($data->suku == 'Suku Ngalum'): ?> selected <?php endif; ?>>Suku Ngalum</option>
                            <option value="Suku Pyu" <?php if($data->suku == 'Suku Pyu'): ?> selected <?php endif; ?>>Suku Pyu</option>
                            <option value="Suku Roon" <?php if($data->suku == 'Suku Roon'): ?> selected <?php endif; ?>>Suku Roon</option>
                            <option value="Suku Sasawa" <?php if($data->suku == 'Suku Sasawa'): ?> selected <?php endif; ?>>Suku Sasawa</option>
                            <option value="Suku Sebyar" <?php if($data->suku == 'Suku Sebyar'): ?> selected <?php endif; ?>>Suku Sebyar</option>
                            <option value="Suku Sentani" <?php if($data->suku == 'Suku Sentani'): ?> selected <?php endif; ?>>Suku Sentani</option>
                            <option value="Suku Serui" <?php if($data->suku == 'Suku Serui'): ?> selected <?php endif; ?>>Suku Serui</option>
                            <option value="Suku Wamesa" <?php if($data->suku == 'Suku Wamesa'): ?> selected <?php endif; ?>>Suku Wamesa</option>
                            <option value="Suku Yali" <?php if($data->suku == 'Suku Yali'): ?> selected <?php endif; ?>>Suku Yali</option>
                            <option value="Suku Lainnya" <?php if($data->suku == 'Suku Lainnya'): ?> selected <?php endif; ?>>Suku Lainnya</option>

                          </select>
                          <!-- <input class="input--style-4" type="text" name="agama" required> -->
                        </div>>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Wilayah Adat: </label>
                        <!-- <input class="input--style-4" type="text" name="wilayah_adat" value="<?php echo e($data->wilayah_adat); ?>" required> -->
                        <div class="input-group">
                          <select class="form-select" id="inputGroupSelect03" name="wilayah_adat" required>
                            <option selected value="Mamta" <?php if($data->wilayah_adat == 'Mamta'): ?> selected <?php endif; ?>>Mamta</option>
                            <option value="Saereri" <?php if($data->wilayah_adat == 'Saereri'): ?> selected <?php endif; ?>>Saereri</option>
                            <option value="Domberai" <?php if($data->wilayah_adat == 'Domberai'): ?> selected <?php endif; ?>>Domberai</option>
                            <option value="Bomberai" <?php if($data->wilayah_adat == 'Bomberai'): ?> selected <?php endif; ?>>Bomberai</option>
                            <option value="Anim Ha" <?php if($data->wilayah_adat == 'Anim Ha'): ?> selected <?php endif; ?>>Anim Ha</option>
                            <option value="La Pago" <?php if($data->wilayah_adat == 'La Pago'): ?> selected <?php endif; ?>>La Pago</option>
                            <option value="Meepago" <?php if($data->wilayah_adat == 'Meepago'): ?> selected <?php endif; ?>>Meepago</option>
                          </select>
                          <!-- <input class="input--style-4" type="text" name="agama" required> -->
                        </div>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Email: </label>
                        <input class="input--style-4" type="email" name="email" value="<?php echo e($data->email); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="">
                    <div class="input-group">
                      <label class="label">No. Telp: </label>
                      <input class="input--style-4" type="number" name="phone" value="<?php echo e($data->telpon); ?>" required>
                    </div>
                  </div> <br> <br>
                  <h1 class="title_2">Data Lembaga Studi</h1>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Nama Lembaga Studi: </label>
                        <input class="input--style-4" type="text" name="nama_lembaga" value="<?php echo e($data->nama_lembaga); ?>" required>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Jenis: </label>
                        <div class="input-group">
                          <select class="form-select" id="inputGroupSelect02" name="pekerjaan" value="pekerjaan" required>
                            <option selected value="Negeri" <?php if($data->jenis == 'Negeri'): ?> selected <?php endif; ?>>Negeri</option>
                            <option value="Swasta" <?php if($data->jenis == 'Swasta'): ?> selected <?php endif; ?>>Swasta</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Tahun Masuk: </label>
                        <input class="input--style-4" type="date" name="tahun_msk" value="<?php echo e($data->tahun_masuk); ?>" required>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Tahun Lulus: </label>
                        <input class="input--style-4" type="date" name="tahun_lls" value="<?php echo e($data->tahun_lulus); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <label class="label">Jenjang Studi: </label>
                      <select class="form-select" id="inputGroupSelect02" name="jenjang" value="jenjang">
                        <option selected value="D3" <?php if($data->jenjang_studi == 'D3'): ?> selected <?php endif; ?>>D3</option>
                        <option value="S1" <?php if($data->jenjang_studi == 'S1'): ?> selected <?php endif; ?>>S1</option>
                        <option value="S2" <?php if($data->jenjang_studi == 'S2'): ?> selected <?php endif; ?>>S2</option>
                        <option value="S3" <?php if($data->jenjang_studi == 'S3'): ?> selected <?php endif; ?>>S3</option>
                      </select>
                      </select>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Alamat Lembaga Studi: </label>
                        <input class="input--style-4" type="text" name="alamat_lembaga" value="<?php echo e($data->alamat_lembaga); ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Provinsi: </label>
                        <div class="input-group">
                          <select name="province_id" id="province_id" class="form-control" required>
                            <option hidden><?php echo e($data->provinsi); ?></option>
                            <?php $__currentLoopData = $provinsi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>" namaprovinsi="<?php echo e($row->provinsi); ?>"><?php echo e($row->provinsi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Kabupaten/Kota: </label>
                        <div class="input-group">
                          <select name="kota" id="kota" class="form-control" required>
                            <option hidden><?php echo e($data->kabupaten); ?></option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div> <br> <br>
                  <h1 class="title_2">Pekerjaan</h1>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Jenis Pekerjaan: </label>
                        <input class="input--style-4" type="text" name="jenis_pekerjaan" value="<?php echo e($data->jenis_pekerjaan); ?>">
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Jabatan: </label>
                        <input class="input--style-4" type="text" name="jabatan" value="<?php echo e($data->jabatan); ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Nama Perusahaan/Organisasi: </label>
                        <input class="input--style-4" type="text" name="nama_perusahaan" value="<?php echo e($data->nama_perusahaan); ?>">
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Alamat Perusahaan/Organisasi: </label>
                        <input class="input--style-4" type="text" name="alamat_perusahaan" value="<?php echo e($data->alamat_perusahaan); ?>">
                      </div>
                    </div>
                  </div> <br> <br>
                  <h1 class="title_2">Jenis Kegiatan Yang Pernah Diikuti</h1>
                  <div class="row row-space">
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Nama Kegiatan: </label>
                        <input class="input--style-4" type="text" name="nama_kegiatan" value="<?php echo e($data->nama_kegiatan); ?>">
                      </div>
                    </div>
                    <div class="col-2">
                      <div class="input-group">
                        <label class="label">Tahun: </label>
                        <input class="input--style-4" type="date" name="tahun_kegiatan" value="<?php echo e($data->tahun_kegiatan); ?>">
                      </div>
                    </div>
                  </div>
                  <div class="">
                    <div class="input-group">
                      <label class="label">Tempat Kegiatan: </label>
                      <input class="input--style-4" type="text" name="tempat_kegiatan" value="<?php echo e($data->tempat_kegiatan); ?>">
                    </div>
                  </div> <br> <br>
                  <div class="p-t-15">
                    <button class="btn btn--radius-2 btn--blue" type="submit">Save</button>
                    <a href="/data_Alumni"><button type="button" class="btn btn--radius-2 btn-danger">Cancel</button></a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
      <!-- partial -->
    </div>
    <!-- main-panel ends -->
  </div>
  <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../alumni/assets/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="../alumni/assets/vendors/chart.js/Chart.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="../alumni/assets/js/off-canvas.js"></script>
  <script src="../alumni/assets/js/hoverable-collapse.js"></script>
  <script src="../alumni/assets/js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page -->
  <script src="../alumni/assets/js/dashboard.js"></script>
  <script src="../alumni/assets/js/todolist.js"></script>
  <!-- End custom js for this page -->
  <script type="text/javascript" async="" src="https://www.google-analytics.com/analytics.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="../alumni/assets2/vendor/select2/select2.min.js"></script>
  <script src="../alumni/assets2/vendor/datepicker/moment.min.js"></script>
  <script src="../alumni/assets2/vendor/datepicker/daterangepicker.js"></script>
  <script src="../alumni/assets2/js/global.js"></script>
  <div class="daterangepicker dropdown-menu ltr single opensright">
    <div class="calendar left single" style="display: block;">
      <div class="daterangepicker_input"><input class="input-mini form-control" type="text" name="daterangepicker_start" value="" style="display: none;"><i class="fa fa-calendar glyphicon glyphicon-calendar" style="display: none;"></i>
        <div class="calendar-time" style="display: none;">
          <div></div><i class="fa fa-clock-o glyphicon glyphicon-time"></i>
        </div>
      </div>
      <div class="calendar-table"></div>
    </div>
    <div class="calendar right" style="display: none;">
      <div class="daterangepicker_input"><input class="input-mini form-control" type="text" name="daterangepicker_end" value="" style="display: none;"><i class="fa fa-calendar glyphicon glyphicon-calendar" style="display: none;"></i>
        <div class="calendar-time" style="display: none;">
          <div></div><i class="fa fa-clock-o glyphicon glyphicon-time"></i>
        </div>
      </div>
      <div class="calendar-table"></div>
    </div>
    <div class="ranges" style="display: none;">
      <div class="range_inputs"><button class="applyBtn btn btn-sm btn-success" disabled="disabled" type="button">Apply</button> <button class="cancelBtn btn btn-sm btn-default" type="button">Cancel</button></div>
    </div>
  </div>
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
    gtag('config', 'UA-23581568-13');
  </script>
  <script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
  <script>
    $(document).ready(function() {
      //ini ketika provinsi tujuan di klik maka akan eksekusi perintah yg kita mau
      //name select nama nya "provinve_id" kalian bisa sesuaikan dengan form select kalian
      $('select[name="province_id"]').on('change', function() {
        // kita buat variable provincedid untk menampung data id select province
        let idprov = $(this).val();
        //kita cek jika id di dpatkan maka apa yg akan kita eksekusi
        if (idprov) {
          // jika di temukan id nya kita buat eksekusi ajax GET
          jQuery.ajax({
            // url yg di root yang kita buat tadi
            url: "/kota/" + idprov,
            // aksion GET, karena kita mau mengambil data
            type: 'GET',
            // type data json
            dataType: 'json',
            // jika data berhasil di dapat maka kita mau apain nih
            success: function(data) {
              // jika tidak ada select dr provinsi maka select kota kososng / empty
              $('select[name="kota"]').empty();
              // jika ada kita looping dengan each
              $.each(data, function(key, value) {
                // perhtikan dimana kita akan menampilkan data select nya, di sini saya memberi name select kota adalah kota_id
                $('select[name="kota"]').append('<option value="' + value.kota + '" >' + value.kota + '</option>');
              });
            }
          });
        } else {
          $('select[name="kota"]').empty();
        }
      });
    });
  </script>

  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
  <script>
    $(document).ready(function() {
      $('.select2').select2();
    });
  </script>

  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\newAlu,\resources\views/superadmin/editalumni.blade.php ENDPATH**/ ?>